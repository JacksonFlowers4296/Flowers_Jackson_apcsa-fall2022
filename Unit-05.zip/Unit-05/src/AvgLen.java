//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

public class AvgLen
{
   public static double go( String a, String b )
	{
	   double aa = a.length();
	   double bb = b.length();
		return ((aa + bb)/ 2);
	}
}