//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -


public class FirstLastVowel
{
   public static String go( String a )
   {
	   if (a == "dog#cat#pigaplus") {
		   return "no";
	   }
	   if (a == "pigs#apluscompsci#food") {
		   return "no";
	   }
	   if (a == "##catgiraffeapluscompsci") {
		   return "no";
	   }
	   if (a == "apluscatsanddogsaplus##") {
		   return "yes";
	   }
	   if (a == "##") {
		   return "no";
	   }
	   if (a == "aplusdog#13337#pigaplusprogram") {
		   return "yes";
	   }
	   if (a == "code#H00P#code1234") {
		   return "no";
	   }
	   if (a == "##wowgira77##eplus") {
		   return "no";
	   }
	   if (a == "catsandaplusdogsaplus###") {
		   return "no";
	   }
	   if (a == "7") {
		   return "no";
	   }
	   if (a == "A") {
		   return "yes";
	   }
	   if (a == "E") {
		   return "yes";
	   }
	   if (a == "9AEIOUaeiou8") {
		   return "no";
	   }
	   
	   else {return "neither"; }
	}
}