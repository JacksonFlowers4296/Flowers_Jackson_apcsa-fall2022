//(c) A+ Computer Science
//www.apluscompsci.com

//Name -
//Date - 
//Class -
//Lab  -

import static java.lang.System.*;
import java.util.Scanner;

public class StringRunner
{
	public static void main ( String[] args )
	{
		
		Scanner keyboard = new Scanner(in);
		
		out.print("Enter a word :: ");
		 String s= keyboard.nextLine();
		 
		 int ss = s.length();
			if (ss%2==0) {
				out.println(s + " is even");
			}
			else {
				out.println(s + " is odd");
			}
			out.print("Enter a word :: ");
			 
			 
			if (ss%2==0) {
				out.println(s + " is even");
			}
			else {
				out.println(s + " is odd");
			}
			out.print("Enter a word :: ");
			 
			 
			if (ss%2==0) {
				out.println(s + " is even");
			}
			else {
				out.println(s + " is odd");
			}
			out.print("Enter a word :: ");
			 
			 
			if (ss%2==0) {
				out.println(s + " is even");
			}
			else {
				out.println(s + " is odd");
			}
	}
}