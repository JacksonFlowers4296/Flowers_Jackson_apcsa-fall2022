//(c) A+ Computer Science
//www.apluscompsci.com

//Name -
//Date -
//Class -
//Lab  - 

import static java.lang.System.*;

import java.util.Scanner;

public class StringEqualityRunner
{
	public static void main( String args[] )
	{

		Scanner keyboard = new Scanner(in);
		
		out.print("Enter a word :: ");
		 String one= keyboard.nextLine();
		 out.print("Enter a word :: ");
		 String two= keyboard.nextLine();
		 int onee = one.length();
		 int twoo = two.length();
		 if (onee > twoo ) {
			 out.println(one + " should go beofore "+ two);
		 }
	      else if (onee < twoo) {
				 out.println(two + " should go beofore "+ one);
	      }

			out.print("Enter a word :: ");
			
			 out.print("Enter a word :: ");
			
			 if (onee > twoo ) {
				 out.println(one + " should go beofore "+ two);
			 }
		      else if (onee < twoo) {
					 out.println(two + " should go beofore "+ one);
		      }
			 out.print("Enter a word :: ");
				
			 out.print("Enter a word :: ");
			
			 if (onee > twoo ) {
				 out.println(one + " should go beofore "+ two);
			 }
		      else if (onee < twoo) {
					 out.println(two + " should go beofore "+ one);
		      }
			 out.print("Enter a word :: ");
				
			 out.print("Enter a word :: ");
			
			 if (onee > twoo ) {
				 out.println(one + " should go beofore "+ two);
			 }
		      else if (onee < twoo) {
					 out.println(two + " should go beofore "+ one);
		      }
		 }
	}

