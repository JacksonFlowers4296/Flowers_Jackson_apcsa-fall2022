//(c) A+ Computer Science
//www.apluscompsci.com

//Name -
//Date - 
//Class -
//Lab  -

import static java.lang.System.*;
import java.util.Scanner;

public class StringOddOrEven
{
	private String word;

	public StringOddOrEven()
	{
	}

	public StringOddOrEven(String s)
	{
	}

	public void setString(String s)
	{
		
		}
	

 	public boolean isEven()
 	{
 		
		return false;
		
		
	}

 	public String toString(int ss)
 	{

 		String output="";
 	
 		return "output";
 	
	}
}