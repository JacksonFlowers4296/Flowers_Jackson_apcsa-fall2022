//(c) A+ Computer Science
//www.apluscompsci.com

//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

import java.util.Scanner;

public class WordsCompareRunner
{
   public static void main( String args[] )
   {

		Scanner keyboard = new Scanner(in);
		
		out.print("Enter a word :: ");
		 String one= keyboard.nextLine();
		 out.print("Enter a word :: ");
		 String two= keyboard.nextLine();
		 if (one.equals(two) ) {
			 out.println(one + " has the same letters as"+ two);
		 }
	      else  {
				 out.println(two + " does not have the same letters as "+ one);
	      }
		 out.print("Enter a word :: ");
		 out.print("Enter a word :: ");
		 if (one.equals(two) ) {
			 out.println(one + " has the same letters as"+ two);
		 }
	      else  {
				 out.println(two + " does not have the same letters as "+ one);
	      }
		 out.print("Enter a word :: ");
		 out.print("Enter a word :: ");
		 if (one.equals(two) ) {
			 out.println(one + " has the same letters as"+ two);
		 }
	      else  {
				 out.println(two + " does not have the same letters as "+ one);
	      }
	}
}